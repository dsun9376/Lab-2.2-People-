package people;

public abstract class Person 
{
asfasfas
}
